from telethon import TelegramClient, events, sync


def handler(event, context):
    """
    Entry-point for Serverless Function.
    :param event: request payload.
    :param context: information about current execution context.
    :return: response to be serialized as JSON.
    """
    text = 'Привет! Ты запустил навык.'
    if 'request' in event and \
            'original_utterance' in event['request'] \
            and len(event['request']['original_utterance']) > 0:
        message = event['request']['original_utterance']
        if "новост" in message.lower():
            text = telegramm_news()
    return {
        'version': event['version'],
        'session': event['session'],
        'response': {
            # Respond with the original request or welcome the user if this is the beginning of the dialog and the request has not yet been made.
            'text': text,
            # Don't finish the session after this response.
            'end_session': 'false'
        },
    }


def telegramm_news():
    api_id = 14907003
    api_hash = 'b287149e82286c70b45565db8d37f67f'

    client = TelegramClient('session_name', api_id, api_hash)
    client.start(phone="+79647162004", password="Sasha0707")
    channel_username = 'nedomainer'  # your channel
    otvet = ""
    i = 1
    for message in client.get_messages(channel_username, limit=10):
        otvet += str(i) + " новость" + "\n" + str(message.message)
        # print(message.message)
        i += 1
    return otvet

dictionary = {
  "meta": {
    "locale": "ru-RU",
    "timezone": "UTC",
    "client_id": "ru.yandex.searchplugin/7.16 (none none; android 4.4.2)",
    "interfaces": {
      "screen": {},
      "payments": {},
      "account_linking": {}
    }
  },
  "session": {
    "message_id": 1,
    "session_id": "c728eb59-e414-4046-998e-e2fb46624196",
    "skill_id": "1edebb40-2634-418e-991a-ff7e6a7f45b0",
    "user": {
      "user_id": "7914E1F3B0F96EA71602FFC63B130ADC0657F846A524E842EC59965860D52041"
    },
    "application": {
      "application_id": "08BF5A9B394139257133B8F90A42CA108B3D5D4610F61E8391992ED52E261159"
    },
    "new": False,
    "user_id": "08BF5A9B394139257133B8F90A42CA108B3D5D4610F61E8391992ED52E261159"
  },
  "request": {
    "command": "новост",
    "original_utterance": "Новост",
    "nlu": {
      "tokens": [
        "новост"
      ],
      "entities": [],
      "intents": {}
    },
    "markup": {
      "dangerous_context": False
    },
    "type": "SimpleUtterance"
  },
  "version": "1.0"
}
print(handler(dictionary, ""))